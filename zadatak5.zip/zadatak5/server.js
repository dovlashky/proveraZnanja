const fs = require('fs');
const http = require('http');
const url = require('url');
const querystring = require('query-string');
const PATH = "www/";
let artikli = [
    {
        "id":1,
        "naziv": "Jabuka",
        "cena": 117,
        "imeKompanije": "STR Milkov"
    },
    {
        "id":2,
        "naziv": "Kruska",
        "cena": 67,
        "imeKompanije": "STR Milkov"
    },
    {
        "id":3,
        "naziv": "Malina",
        "cena": 89,
        "imeKompanije": "STR Milkov"
    },
]

 var server = http.createServer(function(req,res){
     let urlObj = url.parse(req.url,true,false);
    if(req.method == 'GET'){
        if (urlObj.pathname == "/dodaj-artikal"){
            fs.readFile(PATH + "dodaj-artikal.html", function (err,data){
                if (err){
                    res.writeHead(404);
                    res.end(JSON.stringify(err));
                    return;
                }
                res.writeHead(200);
                res.end(data);
            });
        }

        if (urlObj.pathname == "/svi-artikli"){
            fs.readFile(PATH + "svi-artikli.html", function (err,data){
                if (err){
                    res.writeHead(404);
                    res.end(JSON.stringify(err));
                    return;
                }
                res.writeHead(200);
                data = JSON.stringify(sviArtikli(querystring.parse(body).imeKompanije));
                res.end(data);
            });
        }

        if (urlObj.pathname == "/izmeni-artikle"){
            fs.readFile(PATH + "izmeni-artikle.html", function (err,data){
                if (err){
                    res.writeHead(404);
                    res.end(JSON.stringify(err));
                    return;
                }
                res.writeHead(200);
                res.end(data);
            });
        }
        
    }
    else if(req.method == 'POST'){
        if(urlObj.pathname == "/dodaj-artikal"){
            var body = '';
                req.on('data', function (data) {
                body += data;
            });
            req.on('end', function () {
                dodajArtikal(querystring.parse(body).id,querystring.parse(body).naziv,
                           querystring.parse(body).cena,querystring.parse(body).imeKompanije);
                res.writeHead(302, {
                    'Location': '/dodaj-artikal'
                });
                res.end();
            });
        }

        if (urlObj.pathname == "/obrisi-artikal"){
            var body = '';
                req.on('data', function (data) {
                body += data;
            });
            req.on('end', function () {
                obrisiArtikal(querystring.parse(body).id);
                res.writeHead(302, {
                    'Location': '/svi-artikli'
                });
                res.end();
            });
        }

        if (urlObj.pathname == "/izmeni-artikle"){
            var body = '';
                req.on('data', function (data) {
                body += data;
            });
            req.on('end', function () {
                izmeniArtikal(querystring.parse(body).id,querystring.parse(body).naziv,
                querystring.parse(body).cena,querystring.parse(body).imeKompanije)
                res.writeHead(302, {
                    'Location': '/izmeni-artikle'
                });
                res.end()
            });
        }
    }
 })

 server.listen(3000);

 function dodajArtikal(id,naziv, cena, imeKompanije){
     let artikal = {
         'id':id,
         'naziv':naziv,
         'cena':cena,
         'imeKompanije':imeKompanije
     }
     artikli.push(artikal);
 }

 function obrisiArtikal(id){
     var novaLista = []
     for(var i=0; i < artikli.length;i++){
         if(artikli[i].id != id){
             novaLista.push(artikli[i]);
         }
     }
     artikli = novaLista;
     return artikli;
 }

 function sviArtikli(imeKompanije){
    var postojiIme = false;
    var novaLista = [];
    for(var i=0; i < artikli.length;i++){
        if(artikli[i].imeKompanije == imeKompanije){
            novaLista.push(artikli[i]);
            postojiIme = true;
        }
    }
    if(postojiIme == true){
        return novaLista;
    }
    else{
        return artikli;
    }
 }

 function izmeniArtikal(id,naziv,cena,imeKompanije){
    var novaLista = [];
    for(var i=0; i < artikli.length;i++){
        if(artikli[i].id == id){
            let artikal = {
                'id':id,
                'naziv':naziv,
                'cena':cena,
                'imeKompanije':imeKompanije
            }
            novaLista.push(artikal);
        }
    }
    artikli = novaLista;
     return artikli;
 }